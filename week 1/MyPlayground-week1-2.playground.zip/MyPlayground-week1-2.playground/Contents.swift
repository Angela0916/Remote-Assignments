import PlaygroundSupport
import UIKit


//: # week 1 assignments
/*: ## Part 1 : Git and GitHub
 2. Here are some Git and GitHub commands we usually use in software development. Please explain the meanings and use cases of them. */
//: * git status - 用來確認當下git的狀態和變更，例如確認 branch 和 commits
//: * git add - 新增檔案至 staging area ，更新確認後便可於其中看到新增的文件及其效用。例如應用 git add .LICENSE.swp，新增認證用途的檔案至 git
//: * git reset - 可將 git 復原至上一個變更前的狀態
//: * git commit - 確認新的資料已新增至 git 當中，例如順利上傳 .LICENSE.swp 認證檔案，可以透過輸入 git commit 得到該檔案的資訊；而資料若有問題或是為無用之空檔案的話，輸入 git commit 在實作中會出現以下反應 Aborting commit due to empty commit message.
//: * git log - 可查看資料提交的紀錄、時間、附註資訊等
//: * git branch - 可確認目前該 git 是否有 branch 及其狀態，也可以用於新增 branch
//: * git merge - 主要用於合併不同 branch 的資訊
//: * git push [repo_name] [branch_name] - 指將branch檔案[branch_name]放到放到遠端 (GitHub) 的資料庫[repo_name]
//: * git remote - 可用來檢視已設定好的遠端資料庫版本，並搭配不同的指令對遠端資料庫進行操作與管理
//: * fork - 可將 GitHub 上別人已經建好的資料複製到自己的 GitHub 帳號內做使用

/*:3. Please describe how to establish a GitHub repo and how to upload the local projects to GitHub. Try to explain your answers with as much detail as possible. */
/*:(1) Establish a GitHub repo : 可將現有的專案／資料夾匯入 Git ，或是 Clone 其他人創建的 Git 資料。
 
(2) 完成新增許可認證與介紹文檔：可使用 git add LICENSE（基本建議使用 MIT License） 和 git commit 等指令完成，若於 GitHub 網站上直接新增，會有填寫步驟，按照規定填寫即可。
 
(3) Upload the local projects to GitHub :
 
 －git clone [GitHub repo的網址] 將 repo 資料 clone 到 local端 以便新增修改資料
 
 －git add 新增修改後的資料
 
 －git commit -m [描述資料的文字]
 
 若既有的 GitHub repo 已建立好認證，則不需再提交認證檔案，應只需認證帳號本身的上傳密碼資訊等
 
(4) 提交或是使用其他指令時，可善用 git status 和 git log 查看目前資料狀態 */

/*: ## Part 2 : Basic
 1. Please explain the difference between let and var. */
/*: let 和 var 皆可用來存取數據用於運算和呈現。
 不同之處為 var 主要用於會變動的數據資訊，let 主要呈現已確認、不會因其它條件變動的數據。*/

/*: 2. In Swift, we usually define a variable through the syntax as below: .var x: Int = 10. We use the formula: 2 * radius * pi to calculate the circumference. Now, please define a variable pi and assign a value to it. You can refer to the syntax above while thinking about using var or let and which data type it should be. */
let pi: Float = 3.14159
//:假設今天要計算的圓半徑為3，可使用以下運算
let radius : Float = 3.0
let circumference = 2 * radius * pi

/*: 3. Declare two constants x and y of type Int then assign any value to them. After that, please calculate the average of x and y and store the result in a constant named average . */
let x: Int = 4
let y: Int = 6
let average = (x + y) / 2

/*: 4. Following Q3, now we want to save the average in a record system, but the system doesn’t accept 65 but 65.0. */
//: * Please solve this problem so that we can put the average in the record system.
//: * Please explain the difference between ( 10 / 3 ) and ( 10.0 / 3.0 ).
let averageFloat = Float(average)

let a = 10 / 3
let b = 10.0 / 3.0
/*: ( 10 / 3 ) 為整數 int 相除，結果為int ; ( 10.0 / 3.0 ) 為包含小數點後數字 float 型式去相除，結果也會為 float 型式。由運算結果可以確認以上說明。 */
/*: feedback__Float((a + b) / 2) 跟 (Float(a + b) / 2) 的結果一樣嗎？這邊的 average 你覺得用哪一種比較適合？*/
/*: 經過實驗，以上兩種形式皆會被偵測使用有誤，原因是a與b的類型並不相同（整數  與有小數點的數值），若要相加（＋＝）必須為同類型數值。 */

/*: 5. Declare two constants that values are 10 and 3 each, then please calculate the remainder and save the result in a constant named remainder. */
let constantA = 10
let constantB = 3
let remainder = constantA % constantB

/*: 6. Swift is a very powerful language that can infer the data type for you ( Type Inference ) while we still need to know the basics well. Please change the following codes into the ones with the type annotation. */
var flag = true
//: var flag : Bool = true

var inputString = "Hello world."
//: var inputString : String = "Hello world."

let bitsInBite = 8
//: let bitsInByte : Int = 8

let averageScore = 86.8
//: let averageScore : Double = 86.8


/*: 7. What is Type Inference in Swift? */
/*: 在 Swift 當中不需主動設定資料為數字或是文檔，也不用特別註記是 int 或 float， Swift 會主動協助判定。*/

/*: 8. What is the issue about this piece of code?
var phoneNumber = 0987654321
phoneNumber = "Hello world." */
/*: 第一行已賦予 phoneNumber 為整數值int 0987654321 ，因此第二行嘗試將 phoneNumber 賦予文字 形式String：Hello world.的要求會被判斷有錯誤。*/

/*: 9. Compound assignment operators are very useful when programming. Please declare a variable salary with initial value 22000, and use unary plus operator adding 28000 to salary, so it will be 50000 after this process. */
var salary = 22000
salary += 28000

/*: 10. You should notice that ‘=’ has a different meaning in programming. In the real world, .‘=’ means equal while in programming, ‘=’ means assign. You simply put the right hand side data into the left hand side variable or constant. Now please write down the Equality operator in Swift. */
//: Swift 中的相等判斷是使用＝＝，以下為使用範例
let tenA = 3
let tenB = 5
tenA == tenB
//: 透過 == 結果判定為 false
tenA != tenB
//: 透過 != 結果判定為二值的確不相等

/*: ## Part 3 : Collection
 You should know how to declare an Array in Swift, and also how to add, remove, insert, read an object in an array. You should be familiar with the following syntax: append , .insert , remove.
 Arrays are dangerous in Swift. If you access the array with an index which is out of range, your app will crash with fatal error. Please interact with the array very carefully. */


/*: 1. Please initialize an empty array with String data type and assign it to a variable named .myFriends. */
var myFriends = [String]()

/*: 2. According to Q1, now I have three friends, ‘Ian’, ‘Bomi’, and ‘Kevin’. Please help me to add their name into myFriends array at once. */
myFriends = ["Ian", "Bomi", "Kevin"]

/*: 3. Oops, I forgot to add ‘Michael’ who is one of my best friends, please help me to add Michael to the end of myFriends array. */
myFriends.append("Michael")

/*: 4. Because I usually hang out with Kevin, please move Kevin to the beginning of the .myFriends array. */
if let kevinIndex = myFriends.firstIndex(of: "Kevin") {
    myFriends.remove(at: kevinIndex)
    myFriends.insert("Kevin", at: 0)
}

/*: 5. Use for...in to print all the friends in myFriends array. */
for friend in myFriends {
    print(friend)
}

/*: 6. Now I want to know who is at index 5 in the myFriends array, try to find the answer for me. Please explain how you get the answer and why the answer is it. */
//: 在 Swift 的 Array 當中，行列中排第一的被設定為第 0 項，因此題目要求的index 5 ，意思為朋友名單中的第六項，但目前名單中只有列出 0/1/2/3 四項，因此無法取得 index 5。

/*: 7. How to get the first element in an array? */
if let firstFriend = myFriends.first {
    print(firstFriend)
}

/*: 8. How to get the last element in an array? */
if let lastFriend = myFriends.last {
    print(lastFriend)
}

/*: 9. Please initialize a Dictionary with keys of type String, value of type Int, and assign it to a variable named myCountryNumber. */
var myCountryNumber = [String: Int]()

/*: 10. Please add three values 1, 44, 81 to myCountryNumber for keys ‘US’, ‘GB’, ‘JP’ respectively. */
myCountryNumber = ["US":1, "GB":44, "JP":81]

/*: 11. Change the value of ‘GB’ from 44 to 0. */
myCountryNumber["GB"] = 0

/*: 12. How to declare an empty dictionary? */
//:可以使用 var emptyDictionary = [KeyType: ValueType]()

/*: 13. How to remove a key-value pair in a dictionary? */
//:可以利用 nil 協助執行
myCountryNumber["GB"] = nil
//:也可利用另外的數值設定將 key-value pair 排除
let removedValue = myCountryNumber.removeValue(forKey: "JP")

/*: ## Part 4 : Control Flow
 1. Here is an array:
let lottoNumbers = [10, 9, 8, 7, 6, 5]
 Please use For-In loop and Range to print the last three members in the
 lottoNumbers. array. */
let lottoNumbers = [10, 9, 8, 7, 6, 5]
for number in lottoNumbers[3..<lottoNumbers.count] {
    print(number)
}

/*: 2. Please use a for-in loop to print the results as the images listed below respectively (through .lottoNumbers.): */
for number in lottoNumbers.reversed() {
    print(".\(number)")
}

for number in lottoNumbers where number % 2 == 0 {
    print(".\(number)")
}

/*: 3. Please use a while loop to solve the Q2.*/
var indexL = lottoNumbers.count - 1
while indexL >= 0 {
    print(".\(lottoNumbers[indexL])")
    indexL -= 1
}

/*: 4. Please use a repeat-while loop to solve Q2. */
var indexLL = lottoNumbers.count - 1
repeat {
    print(".\(lottoNumbers[indexLL])")
    indexLL -= 1
} while indexLL >= 0

/*: 5. What are the differences between while and repeat-while? */
/*: while 設定當中，會依據提供的條件先判斷下列要執行的 Loop 是否符合，如果符合才會執行，不符合的話不會執行。*/
/*: repeat-while 則是不論條件為何，皆會先執行一遍 Loop ，然後再判斷其結果是否符合條件。*/

/*: 6. Declare a variable isRaining to record the weather. Please write a statement that if the weather is raining, print “It’s raining, I don’t want to work today.”, otherwise print “Although it’s sunny, I still don’t want to work today.” */
let isRaining = true
if isRaining {
    print("It’s raining, I don’t want to work today.")
} else {
    print("Although it’s sunny, I still don’t want to work today.")
}
/*: 7. In a company, we might use numbers to represent job levels. Let’s make an example. We use 1 for the Member, 2 for Team Leader, 3 for Manager, and 4 for Director. Now, declare a variable named jobLevel and assign a number to it. If the jobLevel number is in our list, print the relative job title name; if not, just print “We don't have this job”. Please use the if-else statement and the switch statement to complete this requirement separately. */
//:if-else statement
let jobLevelif = 3
if jobLevelif == 1 {
    print("Member")
} else if jobLevelif == 2 {
    print("Team Leader")
} else if jobLevelif == 3 {
    print("Manager")
} else if jobLevelif == 4 {
    print("Director")
} else {
    print("We don't have this job")
}
//:switch statement
let jobLevelsw = 3
switch jobLevelsw {
case 1:
    print("Member")
case 2:
    print("Team Leader")
case 3:
    print("Manager")
case 4:
    print("Director")
default:
    print("We don't have this job")
}

/*: ## Part 5 : Function
 1. What are the return types in the following statements? */
/*:func birthday( ) -> String {
    
}
此行指 birthday 得出的結果會以 String 形式回覆 */

/*:func payment( ) -> Double {
    
}
此行指 payment 運算後得出的結果會以 Double 數值形式回覆 */

/*: 2. Please declare a function named multiply with two arguments a and b. This function won’t return any value and will only print out the result of a * b. Be noticed that we want to give the argument b a default value of 10. */
func multiply(a2: Int, b2: Int = 10) {
    let result = a2 * b2
    print(result)
}

/*: 3. What’s the difference between argument label and parameter name in a function? */
/*: argument label 和 parameter name 通常為連接的關係。
 argument label 是指用來標示根據 parameter name 的設定，實際應用上的參數顯示，以下為範例*/
 func sayHello(to name: String) {
     print("Hello, \(name)!")
 }
//:此部分為parameter name

 sayHello(to: "Angela")
//:此部分的 to 即為 argument label


/*: 4. Please declare a function named greet with person as an argument label and name as a parameter name. This greet function will return a String. */
func greet(person name: String) -> String {
    return "Hello, \(name)"
}
//實際應用
greet(person: "Luke")



//:作業完成時間：2023/09/03 21:20
